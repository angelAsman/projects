/*
 * execute.h
 *
 *  Created on: Jul 9, 2015
 *      Author: Angel Asman
 */

int execProcess(char **argv);
