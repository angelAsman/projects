/*
 * addtoPath.h
 */

/*
 * Adds the CLI current directory to PATH
 * for execvp() to find CLI built in executables
 */

void changePath();
