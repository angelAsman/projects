/* changeDirectory.h
 * created by:
 * Angel Asman
 *
 * Parameter: command line arguments
 * Changes to specified directory or prints current
 * by comparing argument to specified
 * commands
 * returns: integer
 */

int cwdChange(char **argv);
