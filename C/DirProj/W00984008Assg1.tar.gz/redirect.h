// redirect.h
//created by: Angel Asman

void reDirect(char **argv);
