/*
 * textview.h
 *
 *  Created on: Aug 13, 2015
 *      Author: angel
 */
#include <gtk/gtk.h>

int fill_buffer_Text (GtkTextBuffer* buffer, gchar* filename);
int fill_buffer_Address (GtkTextBuffer* buffer, gchar* filename);
int fill_buffer_Hex (GtkTextBuffer* buffer, gchar* filename);




