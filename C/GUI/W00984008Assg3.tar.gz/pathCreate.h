/*
 * pathCreate.h
 *
 *  Created on: Aug 16, 2015
 *      Author: Angel Asman
 *
 *   This appends a slash and the old path with new path
 *
 */

void createPath(char *newpath, char *oldpath, char *directoryName);
