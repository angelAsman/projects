/*
 * panes.h
 * Created by:
 * Angel Asman
 * Aug 07, 2015
 *
 * This sets up the three resizable panes. In the window container
 */

void makePanes(GtkWidget *window, GtkWidget *hpane, GtkWidget *vpane);
