/*
 * display.h
 *
 *  Created on: Aug 8, 2015
 *      Author: Angel Asman
 */
#include <gtk/gtk.h>

void display(GtkWidget *window, GtkWidget *scroll, GtkWidget *hpaned);

